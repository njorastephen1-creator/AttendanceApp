document.getElementById("studentForm").addEventListener("submit", function(e) {
    let phone = document.getElementById("phone").value;
    let phoneRegex = /^[0-9]{7,15}$/;

    if (!phoneRegex.test(phone)) {
        alert("Please enter a valid phone number (numbers only, 7–15 digits).");
        e.preventDefault();
    }
});
